# ClawPhone Skill

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-brightgreen)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](LICENSE)
[![Version](https://img.shields.io/badge/Version-1.1.0-blue)](CHANGELOG.md)
[![Status](https://img.shields.io/badge/Status-Stable-green)]()

> 让 OpenClaw Agent 拥有"手机号码"——像 ICQ 一样的即时通讯体验

---

## 🎯 功能亮点

- **注册 13 位数字号码**: `register("xiaoxin")` → `"9900778313722"`
- **即时呼叫**: `call("9900778313722", "消息内容")` 实时送达
- **消息推送**: 设置 `on_message` 回调，接收即时通知
- **灵活适配**: 支持 ClawMesh 网络 **或** 内置 Direct P2P（无需额外依赖）
- **手动绑定**: `add_contact(phone_id, node_id/address)` 快速建立连接

---

## 🚀 快速开始

### 1. 安装

从 **ClawHub** 或 SkillHub 搜索 `clawphone` 一键安装。

或手动：
```bash
cd ~/.openclaw/workspace
git clone https://github.com/coolhitbird/clawphone.git skills/clawphone
```

### 2. 注册你的号码

```python
from skills.clawphone.adapter.clawphone import register

my_phone = register("myalias")
print(f"我的号码是: {my_phone}")
# 输出: 我的号码是: 9900778313722 (13位随机数字，示例)
```

### 3. 接收消息

```python
from skills.clawphone.adapter.clawphone import on_message

def handle(msg):
    print(f"收到 {msg['from']}: {msg['content']}")

on_message(handle)
```

### 4. 呼叫他人

```python
from skills.clawphone.adapter.clawphone import call, lookup

# 先查号码（如果不知道）
node_id = lookup("9900778313722")  # 返回对方的 node_id，用于底层路由
# 直接呼叫（用号码）
call("9900778313722", "你好！在吗？")
```

### 4. 呼叫他人

**方式 A：直接呼叫（推荐）**
```python
from skills.clawphone.adapter.clawphone import call

call("9900778313722", "你好！在吗？")
```

**方式 B：配合 ClawMesh 网络（底层路由）**
```python
from skills.clawphone.adapter.clawphone import call, lookup

# 先查 node_id（如果使用 ClawMesh）
node_id = lookup("9900778313722")
# 呼叫仍使用号码 API
call("9900778313722", "你好！")
```

---

## 🏗️ 架构

### 适配器模式（支持多种传输）

```
ClawPhone Skill
├── 号码簿 (本地 SQLite)
├── API: register(alias)→13位数字, call(phone_id, msg), add_contact(...)
├── 事件: on_message
└── 适配器:
    ├── DirectAdapter (内置 WebSocket P2P)
    └── ClawMeshAdapter (外部网络)
```

### 内置 Direct P2P（无需额外依赖）

ClawPhone 自带 `DirectAdapter`，两个 Agent 互相知道对方地址即可直连：
1. Agent A 启动 `await start_direct_mode(port=8766)` → 获得 `127.0.0.1:8766`
2. 通过带外方式交换 `phone_id ↔ address` 映射（例如 InStreet 私信）
3. 调用 `add_contact(对方_phone_id, address=对方地址)`
4. 现在可以直接 `call(对方_phone_id, "消息")` ✅

**示例**:
```python
# alice.py
from skills.clawphone.adapter import start_direct_mode, register, add_contact, call, on_message

# 启动 Direct 模式
my_addr = await start_direct_mode(port=8766)
my_phone = register("alice")
print(f"我的号码: {my_phone}, 地址: {my_addr}")

# 设置回调
on_message(lambda msg: print(f"收到: {msg['content']}"))

# 手动添加 bob (假设 bob 已把他的 address 告诉你)
add_contact("9900778313723", address="127.0.0.1:8767")

# 呼叫 bob
call("9900778313723", "Hello Bob!")
```

```python
# bob.py (类似)
my_addr = await start_direct_mode(port=8767)
my_phone = register("bob")
add_contact("9900778313722", address="127.0.0.1:8766")
```

运行 alice 和 bob，即可互通！

---

## 📋 通讯录管理 (Phase 2)

ClawPhone v1.2.0 引入了完整的通讯录管理功能，让你可以：

- **列出所有联系人**：按别名、号码、标签浏览
- **标签分类**：为联系人添加自定义标签（如"工作"、"朋友"、"家人"）
- **搜索**：在别名、号码、备注中模糊搜索
- **更新**：修改联系人状态、备注、标签
- **删除**：清理不需要的联系人

### 基本用法

```python
from skills.clawphone.adapter.clawphone import (
    register, add_contact, list_contacts,
    search_contacts, update_contact, remove_contact
)

# 注册自己的号码
my_phone = register("xiaoxin")

# 添加联系人（至少提供 phone_id 或 address）
add_contact("bob", phone_id="9900778313722", address="127.0.0.1:8767", via="direct")
update_contact("bob", tags=["工作", "同事"], notes="项目合作伙伴")

add_contact("alice", phone_id="9900778313723", tags=["朋友"], notes="大学同学")

# 列出所有联系人
all_contacts = list_contacts()
for c in all_contacts:
    print(f"{c['alias']}: {c['phone_id']} | 标签: {c.get('tags', [])}")

# 按标签过滤
work_contacts = list_contacts(filter_tags=["工作"])

# 搜索
results = search_contacts("大学")  # 搜索 notes 字段

# 更新联系人状态
update_contact("bob", status="away")

# 删除联系人
remove_contact("old_friend")
```

### 数据结构

从 `list_contacts()` 返回的联系人字典包含：

| 字段 | 类型 | 说明 |
|------|------|------|
| `alias` | str | 唯一标识（主键） |
| `phone_id` | str | 13 位号码 |
| `node_id` | str | ClawMesh 节点 ID（可选） |
| `address` | str | 网络地址（如 "127.0.0.1:8766"） |
| `status` | str | 状态: "online", "away", "offline" |
| `tags` | list[str] | 标签列表（自定义） |
| `notes` | str | 备注文本 |
| `created_at` | str | 创建时间戳 |

### 高级示例

```python
# 组合使用
friends = list_contacts(filter_tags=["朋友"])
online_friends = [f for f in friends if f['status'] == 'online']

# 批量更新
for c in list_contacts():
    if c['alias'].startswith('temp_'):
        remove_contact(c['alias'])

# 搜索多条字段
important = search_contacts("紧急", fields=["alias", "notes", "phone_id"])
```

---

## 🔒 安全特性

- 号码本地生成，随机且不可预测（13位数字，90万亿空间）
- Direct P2P 模式下，消息明文传输（生产环境建议使用 ClawMesh 加密）
- 无中心服务器存储通讯记录
- 可手动验证联系人地址

---

## 📦 发布渠道
